const Days = document.getElementById("days");
const Hours = document.getElementById("hours");
const Minutes = document.getElementById("minutes");
const Seconds = document.getElementById("seconds");

const countDownDate = new Date("July 1, 2024 00:00:00").getTime();
const x = setInterval(() => {
  const now = new Date().getTime();
  const distance = countDownDate - now;
  const time = {
    days: Math.floor(distance / (1000 * 60 * 60 * 24)),
    hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
    minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
    seconds: Math.floor((distance % (1000 * 60)) / 1000),
  };

  if (distance < 0) {
    clearInterval(x);
    Days.innerHTML = "00";
    Hours.innerHTML = "00";
    Minutes.innerHTML = "00";
    Seconds.innerHTML = "00";
  } else {
    Days.innerHTML = time.days;
    Hours.innerHTML = time.hours;
    Minutes.innerHTML = time.minutes;
    Seconds.innerHTML = time.seconds;
  }
}, 1000);
