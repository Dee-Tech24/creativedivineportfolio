const btc = document.getElementById("bitcoin");
const eth = document.getElementById("ethereum");
const doge = document.getElementById("dogecoin");

const settings = {
  async: true,
  scrossDomain: true,
  url: "curl --request GET \
     --url https://pro-api.coingecko.com/api/v3/onchain/simple/networks/network/token_price/addresses \
     --header 'accept: application/json'",
  method: "GET",
  headers: {},
};

$.ajax(settings).done(function (response) {
  btc.innerHTML = response.bitcoin.usd;
  eth.innerHTML = response.ethereum.usd;
  doge.innerHTML = response.dogecoin.usd;
});
